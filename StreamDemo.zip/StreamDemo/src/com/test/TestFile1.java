package com.test;

import java.io.File;

public class TestFile1 {

	public static void main(String[] args) {
		String str = "C:/Windows";
		//String str = "sample.txt";
		File filename = new File(str);
		if(filename.exists() && filename.isDirectory())
		{
			
			String [] listOfFiles=filename.list();
			
			for(String str1 : listOfFiles )
		{
			System.out.print(str1);
		}
	}
		else
		{
			System.out.println(" FILE NOT FOUND ");
		}
		
	}

}
