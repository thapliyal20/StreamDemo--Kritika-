package com.test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class TestValidation {
	public static void main(String[] args) 
	{	 
		//String input="a";
		//String input="9876543210";
		long mobile=9876543210l;
		
		//Pattern pattern=Pattern.compile("[a-z]{2,6}");
		//Pattern pattern=Pattern.compile("[A-Z]{2,6}");
		//Pattern pattern=Pattern.compile("^[A-Z]{2,6}^");
		Pattern pattern=Pattern.compile("[0-9]{10}");
		
		//Matcher matcher= pattern.matcher(input);
		Matcher matcher= pattern.matcher(String.valueOf(mobile));
		
		System.out.println(matcher.matches());
	}
}
