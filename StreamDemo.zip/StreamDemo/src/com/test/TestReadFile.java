package com.test;

//import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
//import java.io.BufferReader;
import java.io.LineNumberReader;

public class TestReadFile {

	public static void main(String[] args) {
		
		
		try {
			FileReader fr= new FileReader("Employee.java");
			LineNumberReader br=new LineNumberReader(fr);
			//BufferedReader br=new BufferedReader(fr);
			
			String str=null;
		while((str=br.readLine()) != null)
{
			System.out.println(br.getLineNumber()+" "+str);
			}

		br.close();
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
}

